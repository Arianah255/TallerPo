import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ingreso de datos para el estudiante
        System.out.println("Ingrese los datos del estudiante:");
        System.out.print("Nombre: ");
        String nombreEstudiante = scanner.nextLine();
        System.out.print("Dirección: ");
        String direccionEstudiante = scanner.nextLine();
        System.out.print("Teléfono: ");
        String telefonoEstudiante = scanner.nextLine();
        System.out.print("Correo Electrónico: ");
        String correoEstudiante = scanner.nextLine();
        System.out.print("Estado (1-4): ");
        int estadoEstudiante = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer de entrada

        // Crear objeto estudiante
        Estudiante estudiante = new Estudiante(nombreEstudiante, direccionEstudiante, telefonoEstudiante, correoEstudiante, estadoEstudiante);

        // Ingreso de datos para el empleado
        System.out.println("\nIngrese los datos del empleado:");
        System.out.print("Nombre: ");
        String nombreEmpleado = scanner.nextLine();
        System.out.print("Dirección: ");
        String direccionEmpleado = scanner.nextLine();
        System.out.print("Teléfono: ");
        String telefonoEmpleado = scanner.nextLine();
        System.out.print("Correo Electrónico: ");
        String correoEmpleado = scanner.nextLine();
        System.out.print("Departamento (Contabilidad, Recursos Humanos, Compras): ");
        String departamentoEmpleado = scanner.nextLine();
        System.out.print("Salario: ");
        double salarioEmpleado = scanner.nextDouble();
        scanner.nextLine(); // Limpiar el buffer de entrada
        System.out.print("Fecha de Contratación: ");
        String fechaContratacionEmpleado = scanner.nextLine();

        // Crear objeto empleado
        Empleado empleado = new Empleado(nombreEmpleado, direccionEmpleado, telefonoEmpleado, correoEmpleado, departamentoEmpleado, salarioEmpleado, fechaContratacionEmpleado);

        // Imprimir datos del estudiante y empleado
        System.out.println("\nDatos del estudiante:");
        System.out.println(estudiante);
        System.out.println("\nDatos del empleado:");
        System.out.println(empleado);

        scanner.close();
    }
}