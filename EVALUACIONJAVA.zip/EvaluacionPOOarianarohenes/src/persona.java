public class persona {
    protected String nombre;
    protected String direccion;
    protected String telefono;
    protected String correoElectronico;

    public persona(String nombre, String direccion, String telefono, String correoElectronico) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.correoElectronico = correoElectronico;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Dirección: " + direccion + ", Teléfono: " + telefono + ", Correo Electrónico: " + correoElectronico;
    }
}
	

