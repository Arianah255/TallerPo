public class Empleado extends persona {
    private String departamento;
    private double salario;
    private String fechaContratacion;

    public Empleado(String nombre, String direccion, String telefono, String correoElectronico, String departamento, double salario, String fechaContratacion) {
        super(nombre, direccion, telefono, correoElectronico);
        setDepartamento(departamento);
        this.salario = salario;
        this.fechaContratacion = fechaContratacion;
    }

    public void setDepartamento(String departamento) {
        String[] departamentosValidos = {"Contabilidad", "Recursos Humanos", "Compras"};
        boolean departamentoValido = false;
        for (String depto : departamentosValidos) {
            if (depto.equals(departamento)) {
                departamentoValido = true;
                break;
            }
        }
        if (departamentoValido) {
            this.departamento = departamento;
        } else {
            this.departamento = "Recursos Humanos";
        }
    }
    
    public String toString() {
        return super.toString() + ", Departamento: " + departamento + ", Salario: " + salario + ", Fecha de Contratación: " + fechaContratacion;
    }
}
