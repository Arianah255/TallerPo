public class Estudiante extends persona {
    private int estado;

    public Estudiante(String nombre, String direccion, String telefono, String correoElectronico, int estado) {
        super(nombre, direccion, telefono, correoElectronico);
        setEstado(estado);
    }

    public void setEstado(int estado) {
        if (estado >= 1 && estado <= 4) {
            this.estado = estado;
        } else {
            this.estado = 1;
        }
    }
    
    public String toString() {
        return super.toString() + ", Estado: " + estado;
    }
}

