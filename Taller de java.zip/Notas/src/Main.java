
public class Main {

	public static void main(String[] args) {
		
		   Notas notas1 = new Notas("123456", "Matemáticas", 4.5, 3.0);
	        Notas notas2 = new Notas("218329", "Java", 3.0, 2.5);
		 // Imprimir información de los objetos
        System.out.println("Notas 1:");
        System.out.println(notas1);
        System.out.println("Nota final: " + notas1.calcularNotaFinal());
        System.out.println("Aprobó: " + (notas1.aprobo() ? "Sí" : "No"));
        System.out.println();

        System.out.println("Notas 2:");
        System.out.println(notas2);
        System.out.println("Nota final: " + notas2.calcularNotaFinal());
        System.out.println("Aprobó: " + (notas2.aprobo() ? "Sí" : "No"));
        
    
		

	}

}
