import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

     
        System.out.print("Ingrese la cantidad de pesos a convertir: ");
        double cantidadPesos = scanner.nextDouble();

        
        Conversor conversor = new Conversor();
        conversor.setPesos(cantidadPesos);

        
        System.out.println("Valor en dólares: " + conversor.convertirDolares());
        System.out.println("Valor en euros: " + conversor.convertirEuros());


	}

}
