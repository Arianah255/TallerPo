
public class Conversor {
	double pesos;

	public double getPesos() {
		return pesos;
	}

	public void setPesos(double pesos) {
		this.pesos = pesos;
	}

	    public double convertirDolares() {
	        return pesos / 4000; 
	    }

	    public double convertirEuros() {
	        return pesos / 4500;  
	    }

	    @Override
	    public String toString() {
	        return "Conversor [Pesos: " + pesos + "]";
	
	    }
	    }
