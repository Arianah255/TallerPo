
public class Main {

	public static void main(String[] args) {
		 Circulo circulo = new Circulo(5);
	        System.out.println("Área del círculo: " + circulo.calcularArea());
	        System.out.println("Perímetro del círculo: " + circulo.calcularPerimetro());

	        // Crear una instancia de un cuadrado
	        Cuadrado cuadrado = new Cuadrado(4);
	        System.out.println("Área del cuadrado: " + cuadrado.calcularArea());
	        System.out.println("Perímetro del cuadrado: " + cuadrado.calcularPerimetro());

	        // Crear una instancia de un rectángulo
	        Rectangulo rectangulo = new Rectangulo(3, 6);
	        System.out.println("Área del rectángulo: " + rectangulo.calcularArea());
	        System.out.println("Perímetro del rectángulo: " + rectangulo.calcularPerimetro());

	}

}
