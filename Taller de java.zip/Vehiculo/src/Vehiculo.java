
public class Vehiculo {
	int velocidad;

    public Vehiculo() {
        this.velocidad = 0;
    }

    public void acelerar(int cantidad) {
        velocidad += cantidad;
        System.out.println("El vehículo ha acelerado. Velocidad actual: " + velocidad);
    }

    public void desacelerar(int cantidad) {
        if (velocidad - cantidad >= 0) {
            velocidad -= cantidad;
            System.out.println("El vehículo ha desacelerado. Velocidad actual: " + velocidad);
        } else {
            System.out.println("No se puede desacelerar más. El vehículo está detenido.");
        }
    }

}
