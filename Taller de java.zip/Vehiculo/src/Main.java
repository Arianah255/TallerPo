import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Vehiculo vehiculo = new Vehiculo();

        System.out.println("Programa de control de velocidad de vehículo.");
        char opcion;

        do {
            System.out.println("\nSeleccione una opción:");
            System.out.println("1. Acelerar");
            System.out.println("2. Desacelerar");
            System.out.println("3. Salir");

            opcion = scanner.next().charAt(0);

            switch (opcion) {
                case '1':
                    System.out.print("Ingrese la cantidad de velocidad a aumentar: ");
                    int aceleracion = scanner.nextInt();
                    vehiculo.acelerar(aceleracion);
                    break;
                case '2':
                    System.out.print("Ingrese la cantidad de velocidad a reducir: ");
                    int desaceleracion = scanner.nextInt();
                    vehiculo.desacelerar(desaceleracion);
                    break;
                case '3':
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción inválida. Por favor, seleccione una opción válida.");
                    break;
            }
        } while (opcion != '3');

        scanner.close();
    }
	

}
