
public abstract class Inmueble {
	int codigo;
    String ciudad;
    String direccion;
    double area;
    double valormetrocuadrado;
    double valorarriendomensual;
	//Constructor
    
    public Inmueble(int codigo, String ciudad, String direccion, double area, double valormetrocuadrado,
			double valorarriendomensual) {
		this.codigo = codigo;
		this.ciudad = ciudad;
		this.direccion = direccion;
		this.area = area;
		this.valormetrocuadrado = valormetrocuadrado;
		this.valorarriendomensual = valorarriendomensual;
	}
    //Set y get

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public double getArea() {
		return area;
	}

	public void setArea(double area) {
		this.area = area;
	}

	public double getValormetrocuadrado() {
		return valormetrocuadrado;
	}

	public void setValormetrocuadrado(double valormetrocuadrado) {
		this.valormetrocuadrado = valormetrocuadrado;
	}

	public double getValorarriendomensual() {
		return valorarriendomensual;
	}

	public void setValorarriendomensual(double valorarriendomensual) {
		this.valorarriendomensual = valorarriendomensual;
	}
    //Metodos para calcular el avalúo catastral en pesos y dólares
	abstract int calcularValorVenta();

  abstract double calcularValorVentaDolares();

    public int calcularAvaluoCatastral() {
        if (this instanceof Casa || this instanceof Apartamento) {
            return (int) (calcularValorVenta() * 0.7);
        } else {
            return (int) (calcularValorVenta() * 0.6);
        }
    }

    public double calcularAvaluoCatastralDolares() {
        if (this instanceof Casa || this instanceof Apartamento) {
            return calcularValorVentaDolares() * 0.7;
        } else {
            return calcularValorVentaDolares() * 0.6;
        }
    }
	


}
