
public class Apartamento extends Inmueble {
	int numeroPiso;
	
	 public Apartamento(int codigo, String ciudad, String direccion, double area, double valormetrocuadrado, double valorarriendomensual, int numeroPiso) {
	        super(codigo, ciudad, direccion, area, valormetrocuadrado, valorarriendomensual);
	        this.numeroPiso = numeroPiso;
	    }

	    public int getNumeroPiso() {
	        return numeroPiso;
	    }

	    public void setNumeroPiso(int numeroPiso) {
	        this.numeroPiso = numeroPiso;
	    }

	    @Override
	    public int calcularValorVenta() {
	        return (int) (getArea() * getValormetrocuadrado());
	    }

	    @Override
	    public double calcularValorVentaDolares() {
	        return getArea() * getValormetrocuadrado() / 4000; // Suponiendo que 1 USD = 4000 COP
	    }

}
