
public class Finca extends Inmueble {
	String tipoTerreno;
	
	public Finca(int codigo, String ciudad, String direccion, double area, double valormetrocuadrado, double valorarriendomensual, String tipoTerreno) {
        super(codigo, ciudad, direccion, area, valormetrocuadrado, valorarriendomensual);
        this.tipoTerreno = tipoTerreno;
    }

    public String getTipoTerreno() {
        return tipoTerreno;
    }

    public void setTipoTerreno(String tipoTerreno) {
        this.tipoTerreno = tipoTerreno;
    }

    @Override
    public int calcularValorVenta() {
        return (int) (getArea() * getValormetrocuadrado());
    }

    @Override
    public double calcularValorVentaDolares() {
        return getArea() * getValormetrocuadrado() / 4000; // Suponiendo que 1 USD = 4000 COP
    }
	

}
