
public class Main {

	public static void main(String[] args) {
		 // Crear un apartamento
        Apartamento apartamento = new Apartamento(1, "Bogotá", "Calle 123", 80, 2000000, 1000000, 5);
        System.out.println("Valor de venta del apartamento: " + apartamento.calcularValorVenta());
        System.out.println("Valor de venta del apartamento en dólares: " + apartamento.calcularValorVentaDolares());
        System.out.println("Avalúo catastral del apartamento: " + apartamento.calcularAvaluoCatastral());
        System.out.println("Avalúo catastral del apartamento en dólares: " + apartamento.calcularAvaluoCatastralDolares());

        // Crear una casa
        Casa casa = new Casa(2, "Medellín", "Carrera 456", 150, 1800000, 1200000, 4);
        System.out.println("\nValor de venta de la casa: " + casa.calcularValorVenta());
        System.out.println("Valor de venta de la casa en dólares: " + casa.calcularValorVentaDolares());
        System.out.println("Avalúo catastral de la casa: " + casa.calcularAvaluoCatastral());
        System.out.println("Avalúo catastral de la casa en dólares: " + casa.calcularAvaluoCatastralDolares());

        // Crear una finca
        Finca finca = new Finca(3, "Cali", "Carrera 789", 5000, 1500000, 200000, "Ganadero");
        System.out.println("\nValor de venta de la finca: " + finca.calcularValorVenta());
        System.out.println("Valor de venta de la finca en dólares: " + finca.calcularValorVentaDolares());
        System.out.println("Avalúo catastral de la finca: " + finca.calcularAvaluoCatastral());
        System.out.println("Avalúo catastral de la finca en dólares: " + finca.calcularAvaluoCatastralDolares());

	}

}
