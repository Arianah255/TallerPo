
public class Main {

	public static void main(String[] args) {
		 Sumar suma = new Sumar();

	        // Sumar enteros
	        int resultadoEntero = suma.sumar(1, 2, 3);
	        System.out.println("Suma de enteros: " + resultadoEntero);

	        // Sumar flotantes
	        float resultadoFlotante = suma.sumar(1.5f, 2.5f, 3.5f);
	        System.out.println("Suma de flotantes: " + resultadoFlotante);

	        // Sumar doubles
	        double resultadoDouble = suma.sumar(1.5, 2.5, 3.5);
	        System.out.println("Suma de doubles: " + resultadoDouble);

	}

}
