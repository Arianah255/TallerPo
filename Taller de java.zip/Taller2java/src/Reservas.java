
public class Reservas {
	int id;
    String estado;

    public Reservas(int id, String estado) {
        this.id = id;
        this.estado = estado;
    }

    public void registrar() {
        System.out.println("Se ha registrado la reserva con ID: " + id);
    }

    public void modificar() {
        System.out.println("Se ha modificado la reserva con ID: " + id);
    }

    public void consultar() {
        System.out.println("Consultando reserva con ID: " + id);
    }

    public void cambiarEstado(String nuevoEstado) {
        System.out.println("Se ha cambiado el estado de la reserva con ID " + id + " a " + nuevoEstado);
        this.estado = nuevoEstado;
    }

    @Override
    public String toString() {
        return "Reserva id=" + id + ", estado=" + estado + "";
    }
	
}