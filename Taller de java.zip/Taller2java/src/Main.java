
public class Main {

	public static void main(String[] args) {
		 Reservas reserva1 = new Reservas(1, "Activa");
	     Reservas reserva2 = new Reservas(2, "Pendiente");

	        // Utilizando los métodos de la clase Reservas
	        reserva1.registrar();
	        reserva2.modificar();
	        reserva1.consultar();
	        reserva2.cambiarEstado("Cancelada");

	        // Imprimiendo la información de las reservas utilizando override
	        System.out.println(reserva1);
	        System.out.println(reserva2);

	}

}
