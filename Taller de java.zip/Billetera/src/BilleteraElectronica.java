
public class BilleteraElectronica {
	 double capital;

	    public BilleteraElectronica() {
	        this.capital = 0;
	    }

	    public void depositar(double cantidad) {
	        capital += cantidad;
	        System.out.println("Se ha depositado $" + cantidad + " en la billetera.");
	    }

	    public void retirar(double cantidad) {
	        if (cantidad > capital) {
	            System.out.println("No se puede retirar más dinero del que hay en la billetera.");
	        } else {
	            capital -= cantidad;
	            System.out.println("Se ha retirado $" + cantidad + " de la billetera.");
	        }
	    }

	    public double obtenerCapital() {
	        return capital;
	    }

}
