import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        BilleteraElectronica billetera = new BilleteraElectronica();

        System.out.println("Bienvenido a la billetera electrónica.");

        char opcion;
        do {
            System.out.println("\nSeleccione una opción:");
            System.out.println("1. Depositar dinero");
            System.out.println("2. Retirar dinero");
            System.out.println("3. Ver saldo");
            System.out.println("4. Salir");

            opcion = scanner.next().charAt(0);

            switch (opcion) {
                case '1':
                    System.out.print("Ingrese la cantidad a depositar: $");
                    double deposito = scanner.nextDouble();
                    billetera.depositar(deposito);
                    break;
                case '2':
                    System.out.print("Ingrese la cantidad a retirar: $");
                    double retiro = scanner.nextDouble();
                    billetera.retirar(retiro);
                    break;
                case '3':
                    System.out.println("Su saldo actual es: $" + billetera.obtenerCapital());
                    break;
                case '4':
                    System.out.println("Gracias por utilizar la billetera electrónica.");
                    break;
                default:
                    System.out.println("Opción inválida. Por favor, seleccione una opción válida.");
                    break;
            }
        } while (opcion != '4');

		

	}

}
